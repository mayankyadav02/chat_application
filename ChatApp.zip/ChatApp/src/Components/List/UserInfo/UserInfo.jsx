import React from 'react'
import "./UserInfo.css"
// import MoreHorizIcon from '@mui/icons-material/MoreHoriz';
// import { height } from '@mui/system';
import { useUserStore } from '../../../lib/userStore';

function UserInfo() {
    const {currentUser} = useUserStore();
    
    return (
        <div className='userInfo'>
            <div className="user">
                <img src={currentUser.avatar || "./Avatar.png"} alt="" />
                <h2>{currentUser.username}</h2>
            </div>
            <div className="icons">
                <img src="./more.png" alt="" />
                <img src="./videoCall.png" alt="" />
                <img src="./editing.png" alt="" />
            </div>
        </div>
    )
}

export default UserInfo

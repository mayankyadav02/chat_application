import React, { useState } from 'react'
import "./ChatList.css"
import AddUser from '../../AddUser/AddUser';

function ChatList() {
    const [addMode, setAddMode] = useState(false);
    return (
        <div className='chatList'>
            <div className="search">
                <div className="searchBar">
                    <img src="./searchBar.png" alt="" />
                    <input type="text" placeholder="Search" />
                </div>
                <img src={addMode ? "./minus.png" : "./plus.png" }alt="" 
                className="add"
                onClick={() => setAddMode((prev) => !prev)} />
            </div>
            <div className="item">
                <img src="./Avatar.png" alt="" />
                <div className="texts">
                    <span>Travis Sek</span>
                    <p>Hello</p>
                </div>
            </div>
            <div className="item">
                <img src="./Avatar.png" alt="" />
                <div className="texts">
                    <span>Yashwant</span>
                    <p>Hello</p>
                </div>
            </div>
            <div className="item">
                <img src="./Avatar.png" alt="" />
                <div className="texts">
                    <span>Yashwant</span>
                    <p>Hello</p>
                </div>
            </div>
            {addMode && <AddUser/>}

        </div>
        
    )
}

export default ChatList

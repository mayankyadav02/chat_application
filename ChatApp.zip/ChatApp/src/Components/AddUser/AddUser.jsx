import React from 'react'
import "./AddUser.css"

function AddUser() {
    return (
       <div className='addUser'>
        <form action="">
            <input type="text" placeholder='Username' name='username' />
            <button>Search</button>
        </form>
        <div className="user">
            <div className="detail">
                <img src="./user.png" alt="" />
                <span>Yashwant</span>
            </div>
            <button>Add User</button>
        </div>
       </div>
    )
}

export default AddUser

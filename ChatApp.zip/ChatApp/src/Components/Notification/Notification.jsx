import { ToastContainer } from 'material-react-toastify';
import React from 'react'
import 'material-react-toastify/dist/ReactToastify.css';

function Notification() {
    return (
        <div className=''>
            <ToastContainer position = "bottom-right"/>
        </div>
    )
}

export default Notification
